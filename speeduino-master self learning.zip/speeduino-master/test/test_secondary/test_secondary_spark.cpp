#include <unity.h>
#include <avr/pgmspace.h>
#include "secondaryTables.h"
#include "globals.h"
#include "../test_utils.h"
#include "storage.h"
#include "maths.h"
#include "units.h"

TEST_DATA_P table3d_axis_t tempXAxis[] = {500U/100U, 700U/100U, 900U/100U, 1200U/100U, 1600U/100U, 2000U/100U, 2500U/100U, 3100U/100U, 3500U/100U, 4100U/100U, 4700U/100U, 5300U/100U, 5900U/100U, 6500U/100U, 6750U/100U, 7000U/100U};
TEST_DATA_P table3d_axis_t tempYAxis[] = {16U/2U, 26U/2U, 30U/2U, 36U/2U, 40U/2U, 46U/2U, 50U/2U, 56U/2U, 60U/2U, 66U/2U, 70U/2U, 76U/2U, 86U/2U, 90U/2U, 96U/2U, 100U/2U};

static void __attribute__((noinline)) assert_2nd_spark_is_off(const statuses &current, int8_t expectedAdvance) {
    TEST_ASSERT_FALSE(current.secondSparkTableActive);
    TEST_ASSERT_EQUAL(expectedAdvance, current.advance1);
    TEST_ASSERT_EQUAL(0, current.advance2);
    TEST_ASSERT_EQUAL(current.advance1, current.advance);
} 

static void __attribute__((noinline)) assert_2nd_spark_is_on(const statuses &current, int8_t expectedAdvance1, int8_t expectedAdvance2, int8_t expectedAdvance) {
    TEST_ASSERT_TRUE(current.secondSparkTableActive);
    TEST_ASSERT_EQUAL(expectedAdvance1, current.advance1);
    TEST_ASSERT_EQUAL(expectedAdvance2, current.advance2);
    TEST_ASSERT_EQUAL(expectedAdvance, current.advance);
} 

static void __attribute__((noinline)) test_mode_off_no_secondary_spark(void) {
    config2 page2 = {};
    config10 page10 = {};
    statuses current = {};
    table3d16RpmLoad lookupTable;

    page10.spark2Mode = SPARK2_MODE_OFF;
    page10.spark2Algorithm = LOAD_SOURCE_MAP;
    current.advance1 = 50;
    current.advance = current.advance1;

    calculateSecondarySpark(page2, page10, lookupTable, current);

    assert_2nd_spark_is_off(current, 50);
}

static constexpr int8_t CAP_ADVANCE1 = INT8_MAX - 1;
static constexpr int16_t CAP_LOAD_LOOKUP_RESULT = 150;
static constexpr int16_t CAP_LOAD_VALUE = IGNITION_ADVANCE_LARGE.toUser(CAP_LOAD_LOOKUP_RESULT);

static void __attribute__((noinline)) setup_test_mode_cap_INT8_MAX(config2 &, config10 &page10, statuses &current, table3d16RpmLoad &lookupTable, uint8_t mode) {
    page10.spark2Mode = mode;    
    page10.spark2Algorithm = LOAD_SOURCE_MAP;
    current.advance1 = CAP_ADVANCE1;
    current.advance = current.advance1;
    current.MAP = tempYAxis[0];
    current.setRpm( tempXAxis[0]);
    fill_table_values(lookupTable, CAP_LOAD_LOOKUP_RESULT);
    populate_table_axis_P(lookupTable.axisX.begin(), tempXAxis);
    populate_table_axis_P(lookupTable.axisY.begin(), tempYAxis);
}

static void __attribute__((noinline)) test_mode_cap_INT8_MAX(uint8_t mode, int8_t expectedAdvance2) {
    config2 page2 = {};
    config10 page10 = {};
    statuses current = {};
    table3d16RpmLoad lookupTable;

    setup_test_mode_cap_INT8_MAX(page2, page10, current, lookupTable, mode);

    calculateSecondarySpark(page2, page10, lookupTable, current);

    assert_2nd_spark_is_on(current, CAP_ADVANCE1, expectedAdvance2, INT8_MAX);
}

static constexpr int8_t SIMPLE_ADVANCE1 = 35;
static constexpr int16_t SIMPLE_LOAD_LOOKUP_RESULT = 68;
static constexpr int16_t SIMPLE_LOAD_VALUE = IGNITION_ADVANCE_LARGE.toUser(SIMPLE_LOAD_LOOKUP_RESULT);

static void __attribute__((noinline)) setup_test_mode_simple(config2 &, config10 &page10, statuses &current, table3d16RpmLoad &lookupTable, uint8_t mode) {
    page10.spark2Mode = mode;    
    page10.spark2Algorithm = LOAD_SOURCE_MAP;
    current.advance1 = SIMPLE_ADVANCE1;
    current.advance = current.advance1;
    current.MAP = tempYAxis[0];
    current.setRpm( tempXAxis[0]);
    fill_table_values(lookupTable, SIMPLE_LOAD_LOOKUP_RESULT);
    populate_table_axis_P(lookupTable.axisX.begin(), tempXAxis);
    populate_table_axis_P(lookupTable.axisY.begin(), tempYAxis);
}

static void __attribute__((noinline)) test_mode_simple(uint8_t mode, int8_t expectedAdvance, int8_t expectedAdvance2) {
    config2 page2 = {};
    config10 page10 = {};
    statuses current = {};
    table3d16RpmLoad lookupTable;

    setup_test_mode_simple(page2, page10, current, lookupTable, mode);
    calculateSecondarySpark(page2, page10, lookupTable, current);
    assert_2nd_spark_is_on(current, SIMPLE_ADVANCE1, expectedAdvance2, expectedAdvance);
}

static void __attribute__((noinline)) test_sparkmode_multiply_cap_INT8_MAX(void) {
    test_mode_cap_INT8_MAX(SPARK2_MODE_MULTIPLY, CAP_LOAD_VALUE-INT8_MAX);
}

static void __attribute__((noinline)) test_sparkmode_multiply(uint8_t multiplier) {
    config2 page2 = {};
    config10 page10 = {};
    statuses current = {};
    table3d16RpmLoad lookupTable;

    setup_test_mode_simple(page2, page10, current, lookupTable, SPARK2_MODE_MULTIPLY);
    fill_table_values(lookupTable, IGNITION_ADVANCE_LARGE.toRaw(multiplier));
    calculateSecondarySpark(page2, page10, lookupTable, current);
    assert_2nd_spark_is_on(current, SIMPLE_ADVANCE1, multiplier-INT8_MAX, DIV_ROUND_CLOSEST((SIMPLE_ADVANCE1*multiplier), 100, int16_t));
}

static void __attribute__((noinline)) test_sparkmode_multiply_0(void) {
    test_sparkmode_multiply(0);
}

static void __attribute__((noinline)) test_sparkmode_multiply_50(void) {
    test_sparkmode_multiply(50);
}

static void __attribute__((noinline)) test_sparkmode_multiply_100(void) {
    test_sparkmode_multiply(100);
}

static void __attribute__((noinline)) test_sparkmode_multiply_150(void) {
    test_sparkmode_multiply(150);
}

static void __attribute__((noinline)) test_sparkmode_multiply_200(void) {
    test_sparkmode_multiply(200);
}

static void __attribute__((noinline)) test_sparkmode_multiply_215(void) {
    test_sparkmode_multiply(215);
}

static void __attribute__((noinline)) test_fixed_timing_no_secondary_spark(void) {
    config2 page2 = {};
    config10 page10 = {};
    statuses current = {};
    table3d16RpmLoad lookupTable;

    setup_test_mode_simple(page2, page10, current, lookupTable, SPARK2_MODE_MULTIPLY);
    page2.fixAngEnable = 1U;// Should turn 2nd table off
    calculateSecondarySpark(page2, page10, lookupTable, current);
    assert_2nd_spark_is_off(current, SIMPLE_ADVANCE1);
}

static void __attribute__((noinline)) test_cranking_no_secondary_spark(void) {
    config2 page2 = {};
    config10 page10 = {};
    statuses current = {};
    table3d16RpmLoad lookupTable;

    setup_test_mode_simple(page2, page10, current, lookupTable, SPARK2_MODE_MULTIPLY);
    current.rotationStatus = EngineRotationStatus::Cranking;// Should turn 2nd table off
    calculateSecondarySpark(page2, page10, lookupTable, current);
    assert_2nd_spark_is_off(current, SIMPLE_ADVANCE1);
}

static void __attribute__((noinline)) test_sparkmode_add(void) {
    test_mode_simple(SPARK2_MODE_ADD, SIMPLE_ADVANCE1+SIMPLE_LOAD_VALUE, SIMPLE_LOAD_VALUE);
}

static void __attribute__((noinline)) test_sparkmode_add_cap_INT8_MAX(void) {
    test_mode_cap_INT8_MAX(SPARK2_MODE_ADD, IGNITION_ADVANCE_LARGE.toUser(150));
}

static void __attribute__((noinline)) setup_test_mode_cond_switch(config2 &page2, config10 &page10, statuses &current, table3d16RpmLoad &lookupTable, uint8_t cond, uint16_t trigger) {
    setup_test_mode_simple(page2, page10, current, lookupTable, SPARK2_MODE_CONDITIONAL_SWITCH);
    page10.spark2SwitchVariable = cond;
    page10.spark2SwitchValue = trigger;
    current.MAP = 50; //Load source value
    current.setRpm( 3500U);
    current.TPS = 50;
    current.ethanolPct = 50;
}

static void __attribute__((noinline)) test_sparkmode_cond_switch_negative(uint8_t cond, uint16_t trigger) {
    config2 page2 = {};
    config10 page10 = {};
    statuses current = {};
    table3d16RpmLoad lookupTable;

    setup_test_mode_cond_switch(page2, page10, current, lookupTable, cond, trigger);

    calculateSecondarySpark(page2, page10, lookupTable, current);

    assert_2nd_spark_is_off(current, SIMPLE_ADVANCE1);    
}

static void __attribute__((noinline)) test_sparkmode_cond_switch_positive(uint8_t cond, uint16_t trigger) {
    config2 page2 = {};
    config10 page10 = {};
    statuses current = {};
    table3d16RpmLoad lookupTable;

    setup_test_mode_cond_switch(page2, page10, current, lookupTable, cond, trigger);

    calculateSecondarySpark(page2, page10, lookupTable, current);

    assert_2nd_spark_is_on(current, SIMPLE_ADVANCE1, SIMPLE_LOAD_VALUE, SIMPLE_LOAD_VALUE);
}

static void __attribute__((noinline)) test_sparkmode_cond_switch_rpm(void) {
    test_sparkmode_cond_switch_positive(SPARK2_CONDITION_RPM, 3499);    
    test_sparkmode_cond_switch_negative(SPARK2_CONDITION_RPM, 3501);    
    test_sparkmode_cond_switch_positive(SPARK2_CONDITION_RPM, 3499);    
}

static void __attribute__((noinline)) test_sparkmode_cond_switch_tps(void) {
    test_sparkmode_cond_switch_positive(SPARK2_CONDITION_TPS, 49);    
    test_sparkmode_cond_switch_negative(SPARK2_CONDITION_TPS, 51);    
    test_sparkmode_cond_switch_positive(SPARK2_CONDITION_TPS, 49);    
}

static void __attribute__((noinline)) test_sparkmode_cond_switch_map(void) {
    test_sparkmode_cond_switch_positive(SPARK2_CONDITION_MAP, 49);    
    test_sparkmode_cond_switch_negative(SPARK2_CONDITION_MAP, 51);    
    test_sparkmode_cond_switch_positive(SPARK2_CONDITION_MAP, 49);    
}

static void __attribute__((noinline)) test_sparkmode_cond_switch_ethanol_pct(void) {
    test_sparkmode_cond_switch_positive(SPARK2_CONDITION_ETH, 49);    
    test_sparkmode_cond_switch_negative(SPARK2_CONDITION_ETH, 51);    
    test_sparkmode_cond_switch_positive(SPARK2_CONDITION_ETH, 49);    
}

static void __attribute__((noinline)) test_sparkmode_input_switch(void) {
    config2 page2 = {};
    config10 page10 = {};
    statuses current = {};
    table3d16RpmLoad lookupTable;

    setup_test_mode_simple(page2, page10, current, lookupTable, SPARK2_MODE_INPUT_SWITCH);

    page10.spark2InputPolarity = HIGH;
    pinSpark2Input = 3;   
    pinMode(pinSpark2Input, OUTPUT);

    // On
    digitalWrite(pinSpark2Input, page10.spark2InputPolarity);
    calculateSecondarySpark(page2, page10, lookupTable, current);
    assert_2nd_spark_is_on(current, SIMPLE_ADVANCE1, SIMPLE_LOAD_VALUE, SIMPLE_LOAD_VALUE);

    // Off
    digitalWrite(pinSpark2Input, !page10.spark2InputPolarity);
    current.advance = current.advance1;
    calculateSecondarySpark(page2, page10, lookupTable, current);
    assert_2nd_spark_is_off(current, SIMPLE_ADVANCE1);

    // On again
    digitalWrite(pinSpark2Input, page10.spark2InputPolarity);
    calculateSecondarySpark(page2, page10, lookupTable, current);
    assert_2nd_spark_is_on(current, SIMPLE_ADVANCE1, SIMPLE_LOAD_VALUE, SIMPLE_LOAD_VALUE);
}

void test_calculateSecondarySpark(void)
{
    SET_UNITY_FILENAME() {
        RUN_TEST(test_mode_off_no_secondary_spark);
        RUN_TEST(test_fixed_timing_no_secondary_spark);
        RUN_TEST(test_cranking_no_secondary_spark);
        RUN_TEST(test_sparkmode_multiply_0);
        RUN_TEST(test_sparkmode_multiply_50);
        RUN_TEST(test_sparkmode_multiply_100);
        RUN_TEST(test_sparkmode_multiply_150);
        RUN_TEST(test_sparkmode_multiply_200);
        RUN_TEST(test_sparkmode_multiply_215);
        RUN_TEST(test_sparkmode_multiply_cap_INT8_MAX); 
        RUN_TEST(test_sparkmode_add);
        RUN_TEST(test_sparkmode_add_cap_INT8_MAX);
        RUN_TEST(test_sparkmode_cond_switch_rpm);
        RUN_TEST(test_sparkmode_cond_switch_tps);
        RUN_TEST(test_sparkmode_cond_switch_map);
        RUN_TEST(test_sparkmode_cond_switch_ethanol_pct);
        RUN_TEST(test_sparkmode_input_switch);
    }
}