#include <unity.h>
#include "../test_utils.h"
#include "scheduler.h"
#include "src/stdlib/type_traits.h"

using raw_counter_t = type_traits::remove_reference<IgnitionSchedule::counter_t>::type;
using raw_compare_t = type_traits::remove_reference<IgnitionSchedule::compare_t>::type;

static constexpr uint32_t TIMEOUT = 5000U;
static constexpr uint32_t DURATION = 2000U;
static constexpr COMPARE_TYPE INITIAL_COUNTER = 3333U;

static void test_timeout_TooLarge(void) {
  raw_counter_t counter = { INITIAL_COUNTER };
  raw_compare_t compare = {0};
  Schedule schedule(counter, compare);

  TEST_ASSERT_EQUAL(OFF, schedule._status);
  TEST_ASSERT_EQUAL(0, schedule._duration);
  setSchedule(schedule, MAX_TIMER_PERIOD, DURATION, true);
  TEST_ASSERT_EQUAL(OFF, schedule._status);
  TEST_ASSERT_EQUAL(0, schedule._duration);
}

static void test_timeout_TooSmall(void) {
  raw_counter_t counter = { INITIAL_COUNTER };
  raw_compare_t compare = {0};
  Schedule schedule(counter, compare);

  TEST_ASSERT_EQUAL(OFF, schedule._status);
  TEST_ASSERT_EQUAL(0, schedule._duration);
  setSchedule(schedule, 0U, DURATION, true);
  TEST_ASSERT_EQUAL(OFF, schedule._status);
  TEST_ASSERT_EQUAL(0, schedule._duration);
}

static void test_duration_TooLarge(void) {
  if (MAX_TIMER_PERIOD < (uint32_t)UINT16_MAX)
  {
    raw_counter_t counter = { INITIAL_COUNTER };
    raw_compare_t compare = {0};
    Schedule schedule(counter, compare);

    TEST_ASSERT_EQUAL(OFF, schedule._status);
    TEST_ASSERT_EQUAL(0, schedule._duration);
    setSchedule(schedule, TIMEOUT, (uint16_t)MAX_TIMER_PERIOD+1U, true);
    TEST_ASSERT_EQUAL(PENDING, schedule._status);
    TEST_ASSERT_EQUAL(uS_TO_TIMER_COMPARE(MAX_TIMER_PERIOD - 1U), schedule._duration);
  }
  else
  {
    TEST_IGNORE_MESSAGE("Not applicable to this board");
  }
}

static void test_duration_TooSmall(void) {
  raw_counter_t counter = { INITIAL_COUNTER };
  raw_compare_t compare = {0};
  Schedule schedule(counter, compare);

  TEST_ASSERT_EQUAL(OFF, schedule._status);
  TEST_ASSERT_EQUAL(0, schedule._duration);
  setSchedule(schedule, TIMEOUT, 0U, true);
  TEST_ASSERT_EQUAL(OFF, schedule._status);
  TEST_ASSERT_EQUAL(0, schedule._duration);
}

static void test_schedule_OFF_to_PENDING(void) {
  raw_counter_t counter = { INITIAL_COUNTER };
  raw_compare_t compare = {0};
  Schedule schedule(counter, compare);

  TEST_ASSERT_EQUAL(OFF, schedule._status);
  TEST_ASSERT_EQUAL(0, schedule._duration);
  TEST_ASSERT_EQUAL(0, schedule._nextStartCompare);
  TEST_ASSERT_EQUAL(0, schedule._compare);
  TEST_ASSERT_EQUAL(INITIAL_COUNTER, schedule._counter);
  setSchedule(schedule, TIMEOUT, DURATION, true);
  TEST_ASSERT_EQUAL(PENDING, schedule._status);
  TEST_ASSERT_EQUAL(uS_TO_TIMER_COMPARE(DURATION), schedule._duration);
  TEST_ASSERT_EQUAL(INITIAL_COUNTER + uS_TO_TIMER_COMPARE(TIMEOUT), schedule._compare);
}

static void test_schedule_PENDING_to_PENDING(void) {
  raw_counter_t counter = { INITIAL_COUNTER };
  raw_compare_t compare = {0};
  Schedule schedule(counter, compare);

  // setSchedule(schedule, TIMEOUT, DURATION, true);
  setSchedule(schedule, TIMEOUT+1000, DURATION+500, true);
  TEST_ASSERT_EQUAL(PENDING, schedule._status);
  TEST_ASSERT_EQUAL(uS_TO_TIMER_COMPARE(DURATION+500), schedule._duration);
  TEST_ASSERT_EQUAL(INITIAL_COUNTER + uS_TO_TIMER_COMPARE(TIMEOUT+1000), schedule._compare);
}

static void test_schedule_RUNNING_to_RUNNINGWITHNEXT(void) {
    static_assert(TIMEOUT>DURATION, "Test relies on timeout > duration");
    static constexpr uint32_t DURATION_OFFSET = 33;
    static constexpr uint32_t TIMEOUT_OFFSET = 77;

  raw_counter_t counter = { INITIAL_COUNTER };
  raw_compare_t compare = {0};
  Schedule schedule(counter, compare);

  setSchedule(schedule, TIMEOUT, DURATION, true);
  TEST_ASSERT_EQUAL(INITIAL_COUNTER + uS_TO_TIMER_COMPARE(TIMEOUT), schedule._compare);

  schedule._status = RUNNING;
  setSchedule(schedule, TIMEOUT+TIMEOUT_OFFSET, DURATION+DURATION_OFFSET, true);
  // Should not have changed
  TEST_ASSERT_EQUAL(INITIAL_COUNTER + uS_TO_TIMER_COMPARE(TIMEOUT), schedule._compare);
  // These should have changed
  TEST_ASSERT_EQUAL(RUNNING_WITHNEXT, schedule._status);
  TEST_ASSERT_EQUAL(uS_TO_TIMER_COMPARE(DURATION+DURATION_OFFSET), schedule._duration);
  TEST_ASSERT_EQUAL(INITIAL_COUNTER + uS_TO_TIMER_COMPARE(TIMEOUT+TIMEOUT_OFFSET), schedule._nextStartCompare);
}

static void test_schedule_RUNNINGWITHNEXT_to_RUNNINGWITHNEXT(void) 
{
    static_assert(TIMEOUT>DURATION, "Test relies on timeout > duration");
    static constexpr uint32_t DURATION_OFFSET = 33;
    static constexpr uint32_t TIMEOUT_OFFSET = 77;

  raw_counter_t counter = { INITIAL_COUNTER };
  raw_compare_t compare = {0};
  Schedule schedule(counter, compare);

  setSchedule(schedule, TIMEOUT, DURATION, true);
  TEST_ASSERT_EQUAL(INITIAL_COUNTER + uS_TO_TIMER_COMPARE(TIMEOUT), schedule._compare);

  schedule._status = RUNNING_WITHNEXT;
  setSchedule(schedule, TIMEOUT+TIMEOUT_OFFSET, DURATION+DURATION_OFFSET, true);
  // Should not have changed
  TEST_ASSERT_EQUAL(INITIAL_COUNTER + uS_TO_TIMER_COMPARE(TIMEOUT), schedule._compare);
  TEST_ASSERT_EQUAL(RUNNING_WITHNEXT, schedule._status);
  // These should have changed
  TEST_ASSERT_EQUAL(uS_TO_TIMER_COMPARE(DURATION+DURATION_OFFSET), schedule._duration);
  TEST_ASSERT_EQUAL(INITIAL_COUNTER + uS_TO_TIMER_COMPARE(TIMEOUT+TIMEOUT_OFFSET), schedule._nextStartCompare);
}

static void test_schedule_RUNNING_to_RUNNINGWITHNEXT_Disallow(void) {
  raw_counter_t counter = { INITIAL_COUNTER };
  raw_compare_t compare = {0};
  Schedule schedule(counter, compare);

  setSchedule(schedule, TIMEOUT, DURATION, true);
  TEST_ASSERT_EQUAL(INITIAL_COUNTER + uS_TO_TIMER_COMPARE(TIMEOUT), schedule._compare);

  schedule._status = RUNNING;
  setSchedule(schedule, TIMEOUT+77U, DURATION+66U, false /* This should prevent the schedule being queued*/);
  // Should not have changed
  TEST_ASSERT_EQUAL(INITIAL_COUNTER + uS_TO_TIMER_COMPARE(TIMEOUT), schedule._compare);
  TEST_ASSERT_EQUAL(RUNNING, schedule._status);
  TEST_ASSERT_EQUAL(uS_TO_TIMER_COMPARE(DURATION), schedule._duration);
  TEST_ASSERT_EQUAL(0, schedule._nextStartCompare);
}

void test_schedule(void)
{
  SET_UNITY_FILENAME() {
    RUN_TEST_P(test_timeout_TooLarge);
    RUN_TEST_P(test_timeout_TooSmall);
    RUN_TEST_P(test_duration_TooLarge);
    RUN_TEST_P(test_duration_TooSmall);
    RUN_TEST_P(test_schedule_OFF_to_PENDING);
    RUN_TEST_P(test_schedule_PENDING_to_PENDING);
    RUN_TEST_P(test_schedule_RUNNING_to_RUNNINGWITHNEXT);
    RUN_TEST_P(test_schedule_RUNNINGWITHNEXT_to_RUNNINGWITHNEXT);
    RUN_TEST_P(test_schedule_RUNNING_to_RUNNINGWITHNEXT_Disallow);
  }
}
