/** @file
 * EEPROM Storage updates.
 */
/** Store and load various configs to/from EEPROM considering the the data format versions of various SW generations.
 * This routine is used for doing any data conversions that are required during firmware changes.
 * This prevents users getting difference reports in TS when such a data change occurs.
 * It also can be used for setting good values when there are variables that move locations in the ini.
 * When a user skips multiple firmware versions at a time, this will roll through the updates 1 at a time.
 * The doUpdates() uses may lower level routines from Arduino EEPROM library and storage.ino to carry out EEPROM storage tasks.
 */
#include "globals.h"
#include "storage.h"
#include "sensors.h"
#include "updates.h"
#include "pages.h"
#include "comms_CAN.h"
#include "scheduler.h"
#include "units.h"
#include "unit_testing.h"

// Minimize flash usage of the non-performance critical code in this file.
#pragma GCC optimize ("Os") 

TESTABLE_STATIC void updateTableU16toU8(table2D_u16_u8_32 &targetTable, uint16_t u16EEpromBinAddress)
{
    uint16_t oldValues[32];
    static_assert(targetTable.size()==32U, "Calibration size change - fix this!");

    // Re-read the table axis from the old location
    (void)loadObject(getStorageAPI(), u16EEpromBinAddress, targetTable.axis);

    // Read old values and update table
    (void)loadObject(getStorageAPI(), u16EEpromBinAddress+sizeof(oldValues), oldValues);
    for (uint8_t i = 0; i < targetTable.size(); i++)
    {
      targetTable.values[i] = (uint8_t)oldValues[i];
    }
}

// V26 changed coolant and IAT calibration table **values** from uint16_t to uint8_t
TESTABLE_STATIC void upgradeV25toV26(void) {
  if(loadEEPROMVersion() == 25U)
  {
    // Old EEPROM locations
    constexpr uint16_t OLD_VALUE_SIZE = sizeof(table2D_u16_u16_32::values);
    constexpr uint16_t STORAGE_END = 0xFFF;
    constexpr uint16_t V25_EEPROM_CALIBRATION_CLT_VALUES = STORAGE_END-OLD_VALUE_SIZE;
    constexpr uint16_t V25_EEPROM_CALIBRATION_CLT_BINS =  V25_EEPROM_CALIBRATION_CLT_VALUES-(uint16_t)sizeof(decltype(o2CalibrationTable)::axis);
    constexpr uint16_t V25_EEPROM_CALIBRATION_IAT_VALUES = V25_EEPROM_CALIBRATION_CLT_BINS-OLD_VALUE_SIZE;
    constexpr uint16_t V25_EEPROM_CALIBRATION_IAT_BINS = V25_EEPROM_CALIBRATION_IAT_VALUES-(uint16_t)sizeof(decltype(o2CalibrationTable)::axis);
    constexpr uint16_t V25_EEPROM_CALIBRATION_O2_VALUES = V25_EEPROM_CALIBRATION_IAT_BINS-(uint16_t)sizeof(decltype(o2CalibrationTable)::values);
    constexpr uint16_t V25_EEPROM_CALIBRATION_O2_BINS =   V25_EEPROM_CALIBRATION_O2_VALUES-(uint16_t)sizeof(decltype(o2CalibrationTable)::axis);
    constexpr uint16_t V25_EEPROM_LAST_BARO = (V25_EEPROM_CALIBRATION_O2_BINS-(uint16_t)1);

    updateTableU16toU8(cltCalibrationTable, V25_EEPROM_CALIBRATION_CLT_BINS);
    updateTableU16toU8(iatCalibrationTable, V25_EEPROM_CALIBRATION_IAT_BINS);
    // Read O2 data from old location directly into table
    (void)loadObject(getStorageAPI(), V25_EEPROM_CALIBRATION_O2_BINS, o2CalibrationTable.axis);
    (void)loadObject(getStorageAPI(), V25_EEPROM_CALIBRATION_O2_VALUES, o2CalibrationTable.values);
    
    saveLastBaro(getStorageAPI().read(V25_EEPROM_LAST_BARO));
    saveAllCalibrationTables();

    saveEEPROMVersion(26);
  }
}

void doUpdates(void)
{
  #define CURRENT_DATA_VERSION    26
  //Only the latest update for small flash devices must be retained
   #ifndef SMALL_FLASH_MODE

  //May 2017 firmware introduced a -40 offset on the ignition table. Update that table to +40
  if(loadEEPROMVersion() == 2)
  {
    auto table_it = ignitionTable.values.begin();
    //while (!table_it.at_end()) //at_end() doesn't seem to be working for tables of size 16
    for(uint8_t x=0; x<ignitionTable.values.num_rows;x++)
    {
      auto row = *table_it;
      while (!row.at_end())
      {
        *row = *row + 40;
        ++row;
      }      
      ++table_it;
    }
    saveAllPages();
    saveEEPROMVersion(3);
  }
  //June 2017 required the forced addition of some CAN values to avoid weird errors
  if(loadEEPROMVersion() == 3)
  {
    configPage9.speeduino_tsCanId = 0;
    configPage9.true_address = 256;
    configPage9.realtime_base_address = 336;

    //There was a bad value in the May base tune for the spark duration setting, fix it here if it's a problem
    if(configPage4.sparkDur == UINT8_MAX) { configPage4.sparkDur = 10; }

    saveAllPages();
    saveEEPROMVersion(4);
  }
  //July 2017 adds a cranking enrichment curve in place of the single value. This converts that single value to the curve
  if(loadEEPROMVersion() == 4)
  {
    //Some default values for the bins (Doesn't matter too much here as the values against them will all be identical)
    configPage10.crankingEnrichBins[0] = 0;
    configPage10.crankingEnrichBins[1] = 40;
    configPage10.crankingEnrichBins[2] = 70;
    configPage10.crankingEnrichBins[3] = 100;

    configPage10.crankingEnrichValues[0] = 100 + configPage2.crankingPct;
    configPage10.crankingEnrichValues[1] = 100 + configPage2.crankingPct;
    configPage10.crankingEnrichValues[2] = 100 + configPage2.crankingPct;
    configPage10.crankingEnrichValues[3] = 100 + configPage2.crankingPct;

    saveAllPages();
    saveEEPROMVersion(5);
  }
  //September 2017 had a major change to increase the minimum table size to 128. This required multiple pieces of data being moved around
  if(loadEEPROMVersion() == 5)
  {
    constexpr uint16_t EEPROM_CONFIG10_END_V6 = 2094; 
    //Data after page 4 has to move back 128 bytes
    for(uint16_t x=0U; x < 1152U; x++)
    {
      uint16_t endMem = EEPROM_CONFIG10_END_V6 - x;
      uint16_t startMem = endMem - 128U; //
      (void)update(getStorageAPI(), endMem, getStorageAPI().read(startMem));
    }
    //The remaining data only has to move back 64 bytes
    for(uint16_t x=0; x < 352U; x++)
    {
      uint16_t endMem = EEPROM_CONFIG10_END_V6 - 1152U - x;
      uint16_t startMem = endMem - 64U; //
      (void)update(getStorageAPI(), endMem, getStorageAPI().read(startMem));
    }

    saveEEPROMVersion(6);
    loadAllPages(); //Reload the config after changing everything in EEPROM
  }
  //November 2017 added the staging table that comes after boost and vvt in the EEPROM. This required multiple pieces of data being moved around
  if(loadEEPROMVersion() == 6)
  {
    //Data after page 8 has to move back 82 bytes
    constexpr uint16_t EEPROM_CONFIG10_END_V7 = 2094;

    for(uint16_t x=0U; x < 529U; x++)
    {
      uint16_t endMem = EEPROM_CONFIG10_END_V7 - x;
      uint16_t startMem = endMem - 82U; //
      (void)update(getStorageAPI(), endMem, getStorageAPI().read(startMem));
    }

    saveEEPROMVersion(7);
    loadAllPages(); //Reload the config after changing everything in EEPROM
  }

  if (loadEEPROMVersion() == 7) {
    //Convert whatever flex fuel settings are there into the new tables

    configPage10.flexBoostBins[0] = 0;
    configPage10.flexBoostAdj[0]  = (int8_t)configPage2.aeColdPct;

    configPage10.flexFuelBins[0] = 0;
    configPage10.flexFuelAdj[0]  = configPage2.idleUpPin;

    configPage10.flexAdvBins[0] = 0;
    configPage10.flexAdvAdj[0]  = configPage2.aeTaperMin;

    for (uint8_t x = 1; x < 6; x++)
    {
      uint8_t pct = x * 20;
      configPage10.flexBoostBins[x] = pct;
      configPage10.flexFuelBins[x] = pct;
      configPage10.flexAdvBins[x] = pct;

      int16_t boostAdder = (((configPage2.aeColdTaperMin - (int8_t)configPage2.aeColdPct) * pct) / 100) + (int8_t)configPage2.aeColdPct;
      configPage10.flexBoostAdj[x] = boostAdder;

      uint8_t fuelAdder = (((configPage2.idleUpAdder - configPage2.idleUpPin) * pct) / 100) + configPage2.idleUpPin;
      configPage10.flexFuelAdj[x] = fuelAdder;

      uint8_t advanceAdder = (((configPage2.aeTaperMax - configPage2.aeTaperMin) * pct) / 100) + configPage2.aeTaperMin;
      configPage10.flexAdvAdj[x] = advanceAdder;
    }

    saveAllPages();
    saveEEPROMVersion(8);
  }

  if (loadEEPROMVersion() == 8)
  {
    //May 2018 adds separate load sources for fuel and ignition. Copy the existing load algorithm into Both
    configPage2.fuelAlgorithm = (LoadSource)configPage2.legacyMAP; //Was configPage2.unused2_38c
    configPage2.ignAlgorithm = (LoadSource)configPage2.legacyMAP; //Was configPage2.unused2_38c

    //Add option back in for open or closed loop boost. For all current configs to use closed
    configPage4.boostType = 1;

    saveAllPages();
    saveEEPROMVersion(9);
  }

  if(loadEEPROMVersion() == 9)
  {
    //October 2018 set default values for all the aux in variables (These were introduced in Aug, but no defaults were set then)
    //All aux channels set to Off
    for (byte AuxinChan = 0; AuxinChan <16 ; AuxinChan++)
    {
      configPage9.caninput_sel[AuxinChan] = 0;
    }

    //Ability to change the analog filter values was added. Set default values for these:
    configPage4.ADCFILTER_TPS  = ADCFILTER_TPS_DEFAULT;
    configPage4.ADCFILTER_CLT  = ADCFILTER_CLT_DEFAULT;
    configPage4.ADCFILTER_IAT  = ADCFILTER_IAT_DEFAULT;
    configPage4.ADCFILTER_O2   = ADCFILTER_O2_DEFAULT;
    configPage4.ADCFILTER_BAT  = ADCFILTER_BAT_DEFAULT;
    configPage4.ADCFILTER_MAP  = ADCFILTER_MAP_DEFAULT;
    configPage4.ADCFILTER_BARO = ADCFILTER_BARO_DEFAULT;

    saveAllPages();
    saveEEPROMVersion(10);
  }

  if(loadEEPROMVersion() == 10)
  {
    //May 2019 version adds the use of a 2D table for the priming pulse rather than a single value.
    //This sets all the values in the 2D table to be the same as the previous single value
    configPage2.primePulse[0] = configPage2.aeColdTaperMax / 5; //New priming pulse values are in the range 0-127.5 rather than 0-25.5 so they must be divided by 5
    configPage2.primePulse[1] = configPage2.aeColdTaperMax / 5; //New priming pulse values are in the range 0-127.5 rather than 0-25.5 so they must be divided by 5
    configPage2.primePulse[2] = configPage2.aeColdTaperMax / 5; //New priming pulse values are in the range 0-127.5 rather than 0-25.5 so they must be divided by 5
    configPage2.primePulse[3] = configPage2.aeColdTaperMax / 5; //New priming pulse values are in the range 0-127.5 rather than 0-25.5 so they must be divided by 5
    //Set some sane default temperatures for this table
    configPage2.primeBins[0] = 0;
    configPage2.primeBins[1] = 40;
    configPage2.primeBins[2] = 70;
    configPage2.primeBins[3] = 100;

    //Also added is coolant based ASE for both duration and amount
    //All the adder amounts are set to what the single value was previously
    configPage2.asePct[0] = configPage2.aeColdTaperMin;
    configPage2.asePct[1] = configPage2.aeColdTaperMin;
    configPage2.asePct[2] = configPage2.aeColdTaperMin;
    configPage2.asePct[3] = configPage2.aeColdTaperMin;
    //ASE duration is set to 10s for all coolant values
    configPage2.aseCount[0] = 10;
    configPage2.aseCount[1] = 10;
    configPage2.aseCount[2] = 10;
    configPage2.aseCount[3] = 10;
    //Finally the coolant bins for the above are set to sane values (Remembering these are offset values)
    configPage2.aseBins[0] = 0;
    configPage2.aseBins[1] = 20;
    configPage2.aseBins[2] = 60;
    configPage2.aseBins[3] = 80;

    //Coolant based ignition advance was added also. Set sane values
    configPage4.cltAdvBins[0] = 0;
    configPage4.cltAdvBins[1] = 30;
    configPage4.cltAdvBins[2] = 60;
    configPage4.cltAdvBins[3] = 70;
    configPage4.cltAdvBins[4] = 85;
    configPage4.cltAdvBins[5] = 100;
    configPage4.cltAdvValues[0] = 0;
    configPage4.cltAdvValues[1] = 0;
    configPage4.cltAdvValues[2] = 0;
    configPage4.cltAdvValues[3] = 0;
    configPage4.cltAdvValues[4] = 0;
    configPage4.cltAdvValues[5] = 0;


    //March 19 added a tacho pulse duration that could default to stupidly high values. Check if this is the case and fix it if found. 6ms is the maximum allowed value
    if(configPage2.tachoDuration > 6) { configPage2.tachoDuration = 3; }

    //MAP based AE was introduced, force the AE mode to be TPS for all existing tunes
    configPage2.aeMode = AE_MODE_TPS;
    configPage2.maeThresh = configPage2.taeThresh;
    //Set some sane values for the MAP AE curve
    configPage4.maeRates[0] = 75;
    configPage4.maeRates[1] = 75;
    configPage4.maeRates[2] = 75;
    configPage4.maeRates[3] = 75;
    configPage4.maeBins[0] = 7;
    configPage4.maeBins[1] = 12;
    configPage4.maeBins[2] = 20;
    configPage4.maeBins[3] = 40;

    //The 2nd fuel table was added. To prevent issues, force it to be disabled.
    configPage10.fuel2Mode = 0;


    saveAllPages();
    saveEEPROMVersion(11);
  }

  if(loadEEPROMVersion() == 11)
  {
    //Sep 2019
    //A battery calibration offset value was introduced. Set default value to 0
    configPage4.batVoltCorrect = 0;

    //An option was added to select the older method of performing MAP reads with the pullup resistor active
    configPage2.legacyMAP = 0;

    //Secondary fuel table was added for switching. Make sure it's all turned off initially
    configPage10.fuel2Mode = 0;
    configPage10.fuel2SwitchVariable = 0; //Set switch variable to RPM
    configPage10.fuel2SwitchValue = 7000; //7000 RPM switch point is safe

    saveAllPages();
    saveEEPROMVersion(12);
  }

  if(loadEEPROMVersion() == 12)
  {
    //Nov 2019

    //Manual baro correction curve was added. Give it some default values (All baro readings set to 100%)
    configPage4.baroFuelBins[0] = 80;
    configPage4.baroFuelBins[1] = 85;
    configPage4.baroFuelBins[2] = 90;
    configPage4.baroFuelBins[3] = 95;
    configPage4.baroFuelBins[4] = 100;
    configPage4.baroFuelBins[5] = 105;
    configPage4.baroFuelBins[6] = 110;
    configPage4.baroFuelBins[7] = 115;

    configPage4.baroFuelValues[0] = 100;
    configPage4.baroFuelValues[1] = 100;
    configPage4.baroFuelValues[2] = 100;
    configPage4.baroFuelValues[3] = 100;
    configPage4.baroFuelValues[4] = 100;
    configPage4.baroFuelValues[5] = 100;
    configPage4.baroFuelValues[6] = 100;
    configPage4.baroFuelValues[7] = 100;

    //Idle advance curve was added. Add default values
    configPage2.idleAdvEnabled = IDLEADVANCE_MODE_OFF; //Turn this off by default
    configPage2.idleAdvTPS = 5; //Active below 5% tps
    configPage2.idleAdvRPM = 20; //Active below 2000 RPM
    configPage4.idleAdvBins[0] = 30;
    configPage4.idleAdvBins[1] = 40;
    configPage4.idleAdvBins[2] = 50;
    configPage4.idleAdvBins[3] = 60;
    configPage4.idleAdvBins[4] = 70;
    configPage4.idleAdvBins[5] = 80;
    configPage4.idleAdvValues[0] = 15; //These values offset by 15, so this is just making this equal to 0
    configPage4.idleAdvValues[1] = 15;
    configPage4.idleAdvValues[2] = 15;
    configPage4.idleAdvValues[3] = 15;
    configPage4.idleAdvValues[4] = 15;
    configPage4.idleAdvValues[5] = 15;

    saveAllPages();
    saveEEPROMVersion(13);
  }

  if(loadEEPROMVersion() == 13)
  {
    //202005
    //Cranking enrichment range 0..1275% instead of older 0.255, so need to divide old values by 5
    configPage10.crankingEnrichValues[0] = configPage10.crankingEnrichValues[0] / 5;
    configPage10.crankingEnrichValues[1] = configPage10.crankingEnrichValues[1] / 5;
    configPage10.crankingEnrichValues[2] = configPage10.crankingEnrichValues[2] / 5;
    configPage10.crankingEnrichValues[3] = configPage10.crankingEnrichValues[3] / 5;

    //Added the injector timing curve
    //Set all the values to be the same as the first one. 
    configPage2.injAng[0] = configPage2.injAng[0]; //Obviously not needed, but here for completeness
    configPage2.injAng[1] = configPage2.injAng[0];
    configPage2.injAng[2] = configPage2.injAng[0];
    configPage2.injAng[3] = configPage2.injAng[0];
    //The RPMs are divided by 100
    configPage2.injAngRPM[0] = 5;
    configPage2.injAngRPM[1] = 25;
    configPage2.injAngRPM[2] = 45;
    configPage2.injAngRPM[3] = 65;

    //Introduced a DFCO delay option. Default it to 0
    configPage2.dfcoDelay = 0;
    //Introduced a minimum temperature for DFCO. Default it to 40C
    configPage2.dfcoMinCLT = temperatureAddOffset(40);

    //Update flex fuel ignition config values for 40 degrees offset
    for (int i=0; i<6; i++)
    {
      configPage10.flexAdvAdj[i] += 40;
    }
    
    //AE cold modifier added. Default to sane values
    configPage2.aeColdPct = 100;
    configPage2.aeColdTaperMin = 40;
    configPage2.aeColdTaperMax = 100;

    //New PID resolution, old resolution was 100% for each increase, 100% now is stored as 32
    if(configPage6.idleKP >= 8) { configPage6.idleKP = UINT8_MAX; }
    else { configPage6.idleKP = configPage6.idleKP<<5; }
    if(configPage6.idleKI >= 8) { configPage6.idleKI = UINT8_MAX; }
    else { configPage6.idleKI = configPage6.idleKI<<5; }
    if(configPage6.idleKD >= 8) { configPage6.idleKD = UINT8_MAX; }
    else { configPage6.idleKD = configPage6.idleKD<<5; }
    if(configPage10.vvtCLKP >= 8) { configPage10.vvtCLKP = UINT8_MAX; }
    else { configPage10.vvtCLKP = configPage10.vvtCLKP<<5; }
    if(configPage10.vvtCLKI >= 8) { configPage10.vvtCLKI = UINT8_MAX; }
    else { configPage10.vvtCLKI = configPage10.vvtCLKI<<5; }
    if(configPage10.vvtCLKD >= 8) { configPage10.vvtCLKD = UINT8_MAX; }
    else { configPage10.vvtCLKD = configPage10.vvtCLKD<<5; }

    //Cranking enrichment to run taper added. Default it to 0,1 secs
    configPage10.crankingEnrichTaper = 1;
    
    //ASE to run taper added. Default it to 0,1 secs
    configPage2.aseTaperTime = 1;

    // there is now option for fixed and relative timing retard for soft limit. This sets the soft limiter to the old fixed timing mode.
    configPage2.SoftLimitMode = SOFT_LIMIT_FIXED;

    //VSS was added for testing, disable it by default
    configPage2.vssMode = VSS_MODE_OFF;

    saveAllPages();
    saveEEPROMVersion(14);
  }

  if(loadEEPROMVersion() == 14)
  {
    //202008

    //MAJOR update to move the coolant, IAT and O2 calibrations to 2D tables
    
    //These were the values used previously when all calibration tables were 512 long. They need to be retained so the update process (202005 -> 202008) can work
    constexpr uint16_t EEPROM_CALIBRATION_O2_OLD = 2559U;
    constexpr uint16_t EEPROM_CALIBRATION_IAT_OLD = 3071U;
    constexpr uint16_t EEPROM_CALIBRATION_CLT_OLD = 3583U;

    for(uint16_t x=0U; x<decltype(cltCalibrationTable)::size(); ++x) //Each calibration table is 512 bytes long
    {
      uint16_t y = EEPROM_CALIBRATION_CLT_OLD + (x * 16U);
      cltCalibrationTable.values[x] = getStorageAPI().read(y);
      cltCalibrationTable.axis[x] = (x * 32U);

      y = EEPROM_CALIBRATION_IAT_OLD + (x * 16U);
      iatCalibrationTable.values[x] = getStorageAPI().read(y);
      iatCalibrationTable.axis[x] = (x * 32U);

      y = EEPROM_CALIBRATION_O2_OLD + (x * 16U);
      o2CalibrationTable.values[x] = getStorageAPI().read(y);
      o2CalibrationTable.axis[x] = (x * 32U);
    }
    saveAllCalibrationTables();

    //Oil and fuel pressure inputs were introduced. Disable them both by default
    configPage10.oilPressureProtEnbl = false;
    configPage10.oilPressureEnable = false;
    configPage10.fuelPressureEnable = false;
    
    //wmi
    configPage10.wmiEnabled = 0;
    configPage10.wmiMode = 0;
    configPage10.wmiOffset = 0;
    configPage10.wmiIndicatorEnabled = 0;
    configPage10.wmiEmptyEnabled = 0;
    configPage10.wmiAdvEnabled = 0;
    for(int i=0; i<6; i++)
    {
      configPage10.wmiAdvBins[i] = i*100/2;
      configPage10.wmiAdvAdj[i] = IGNITION_ADVANCE_LARGE.toRaw(0);
    }

    //Programmable outputs added. Set all to disabled
    configPage13.outputPin[0] = 0;
    configPage13.outputPin[1] = 0;
    configPage13.outputPin[2] = 0;
    configPage13.outputPin[3] = 0;
    configPage13.outputPin[4] = 0;
    configPage13.outputPin[5] = 0;
    configPage13.outputPin[6] = 0;
    configPage13.outputPin[7] = 0;

    //New multiply MAP option added. Set new option to be the same as old
    configPage2.multiplyMAP = configPage2.crkngAddCLTAdv;
    //New AE option added to allow for PW added in addition to existing PW multiply
    configPage2.aeApplyMode = 0; //Set the AE mode to Multiply

    //Injector priming delay added
    configPage2.primingDelay = 0;
    //ASE taper time added
    configPage2.aseTaperTime = 10; //1 second taper

    saveAllPages();
    saveEEPROMVersion(15);
  }

  if(loadEEPROMVersion() == 15)
  {
    //202012
    configPage10.spark2Mode = 0; //Disable 2nd spark table

    saveAllPages();
    saveEEPROMVersion(16);
  }

  if(loadEEPROMVersion() == 16)
  {
    //Fix for wrong placed page 13
    constexpr uint16_t EEPROM_CONFIG14_END_V16 = 2998U;
    constexpr uint16_t EEPROM_CONFIG13_START_V16 = 2580U;
    constexpr uint16_t SHIFT_DISTANCE = 112U;
    for(uint16_t x=EEPROM_CONFIG14_END_V16; x>=EEPROM_CONFIG13_START_V16; x--)
    {
      (void)update(getStorageAPI(), x, getStorageAPI().read(x-SHIFT_DISTANCE));
    }

    configPage6.iacPWMrun = false; // just in case. This should be false anyways, but sill.
    configPage2.useDwellMap = 0; //Dwell map added, use old fixed value as default

    saveAllPages();
    saveEEPROMVersion(17);
  }

  if(loadEEPROMVersion() == 17)
  {
    //VVT stuff has now 0.5 accuracy, so shift values in vvt table by one.
    auto table_it = vvtTable.values.begin();
    while (!table_it.at_end())
    {
      auto row = *table_it;
      while (!row.at_end())
      {
        *row = *row << 1;
        ++row;
      }      
      ++table_it;
    }

    configPage10.vvtCLholdDuty = configPage10.vvtCLholdDuty << 1;
    configPage10.vvtCLminDuty = configPage10.vvtCLminDuty << 1;
    configPage10.vvtCLmaxDuty = configPage10.vvtCLmaxDuty << 1;

    //VVT2 added, so default values and disable it
    configPage10.vvt2Enabled = 0;
    configPage4.vvt2PWMdir = 0;
    configPage10.TrigEdgeThrd = 0;

    //Old use as On/Off selection is removed, so change VVT mode to On/Off based on that
    if(configPage6.tachoMode == 1) { configPage6.vvtMode = VVT_MODE_ONOFF; }

    //Closed loop VVT improvements. Set safety limits to max/min working values and filter to minimum.
    configPage10.vvtCLMinAng = 0;
    configPage10.vvtCLMaxAng = 200;
    configPage4.ANGLEFILTER_VVT = 0;

    configPage2.idleAdvDelay *= 2; //Increased resolution to 0.5 second
    
    //RPM switch point added for map sample method. Set to 0 to not affect existing tunes.
    configPage2.mapSwitchPoint = 0;

    configPage9.boostByGearEnabled = 0;

    //Added possibility to set minimum programmable output time
    configPage13.outputTimeLimit[0] = 0;
    configPage13.outputTimeLimit[1] = 0;
    configPage13.outputTimeLimit[2] = 0;
    configPage13.outputTimeLimit[3] = 0;
    configPage13.outputTimeLimit[4] = 0;
    configPage13.outputTimeLimit[5] = 0;
    configPage13.outputTimeLimit[6] = 0;
    configPage13.outputTimeLimit[7] = 0;

    saveAllPages();
    saveEEPROMVersion(18);
  }

  if(loadEEPROMVersion() == 18)
  {
    //202202
    configPage2.fanEnable = configPage6.fanUnused; // PWM Fan mode added, but take the previous setting of Fan in use.

    //TPS resolution increased to 0.5%
    //configPage2.taeThresh *= 2;
    configPage2.idleAdvTPS *= 2;
    configPage2.iacTPSlimit *= 2;
    configPage4.floodClear *= 2;
    configPage4.dfcoTPSThresh *= 2;
    configPage6.egoTPSMax *= 2;
    configPage10.lnchCtrlTPS *= 2;
    configPage10.wmiTPS *= 2;
    configPage10.n2o_minTPS *= 2;
    if(configPage10.fuel2SwitchVariable == FUEL2_CONDITION_TPS) { configPage10.fuel2SwitchValue *= 2; }
    if(configPage10.spark2SwitchVariable == SPARK2_CONDITION_TPS) { configPage10.spark2SwitchVariable *= 2; }

    // Each table Y axis need to be updated as well if TPS is the source
    if(configPage2.fuelAlgorithm == LOAD_SOURCE_TPS)
    {
      multiplyTableLoad(&fuelTable,  fuelTable.type_key,  4);
      multiplyTableLoad(&afrTable,   afrTable.type_key,   4);

      for (auto& table : trimTables)
      {
        // Access the type of the table via the type since it's static
        using table_t = typename type_traits::remove_reference<decltype(table)>::type;
        multiplyTableLoad(&table, table_t::type_key, 4);
      }

      if(configPage4.sparkMode == IGN_MODE_ROTARY)
      { 
        for(uint8_t x = 0; x < 8; x++)
        {
          configPage10.rotarySplitBins[x] *= 2;
        }
      }
    }
    if(configPage2.ignAlgorithm == LOAD_SOURCE_TPS) { multiplyTableLoad(&ignitionTable, ignitionTable.type_key, 4); }
    if(configPage10.fuel2Algorithm == LOAD_SOURCE_TPS) { multiplyTableLoad(&fuelTable2, fuelTable2.type_key, 4); }
    if(configPage10.spark2Algorithm == LOAD_SOURCE_TPS) { multiplyTableLoad(&ignitionTable2, ignitionTable2.type_key, 4); }
    multiplyTableLoad(&boostTable, boostTable.type_key, 2); // Boost table used 1.0 previously, so it only needs a 2x multiplier

    if(configPage6.vvtLoadSource == VVT_LOAD_TPS)
    {
      //NOTE: The VVT tables all had 1.0 as the multiply value rather than 2.0 used in all other tables. For this reason they only need to be multiplied by 2 when updating
      multiplyTableLoad(&vvtTable, vvtTable.type_key, 2);
      multiplyTableLoad(&vvt2Table, vvt2Table.type_key, 2);
    }
    else
    {
      //NOTE: The VVT tables all had 1.0 as the multiply value rather than 2.0 used in all other tables. For this reason they need to be divided by 2 when updating
      divideTableLoad(&vvtTable, vvtTable.type_key, 2);
      divideTableLoad(&vvt2Table, vvt2Table.type_key, 2);
    }


    configPage4.vvtDelay = 0;
    configPage4.vvtMinClt = 0;

    //Set SD logging related settings to zero.
    configPage13.onboard_log_csv_separator = 0;
    configPage13.onboard_log_file_style = 0;
    configPage13.onboard_log_file_rate = 0;
    configPage13.onboard_log_filenaming = 0;
    configPage13.onboard_log_storage = 0;
    configPage13.onboard_log_trigger_boot = 0;
    configPage13.onboard_log_trigger_RPM = 0;
    configPage13.onboard_log_trigger_prot = 0;
    configPage13.onboard_log_trigger_Vbat = 0;
    configPage13.onboard_log_trigger_Epin = 0;
    configPage13.onboard_log_tr1_duration = 0;
    configPage13.onboard_log_tr2_thr_on = 0;
    configPage13.onboard_log_tr2_thr_off = 0;
    configPage13.onboard_log_tr3_thr_RPM = 0;
    configPage13.onboard_log_tr3_thr_MAP = 0;
    configPage13.onboard_log_tr3_thr_Oil = 0;
    configPage13.onboard_log_tr3_thr_AFR = 0;
    configPage13.onboard_log_tr4_thr_on = 0;
    configPage13.onboard_log_tr4_thr_off = 0;
    configPage13.onboard_log_tr5_Epin_pin = 0;

    saveAllPages();
    saveEEPROMVersion(19);
  }
  
  if(loadEEPROMVersion() == 19)
  {
    //202207

    //Option added to select injector pairing on 4 cylinder engines
    if( configPage4.inj4cylPairing > INJ_PAIR_14_23 ) { configPage4.inj4cylPairing = 0; } //Check valid value
    if( configPage2.nCylinders == 4 )
    {
      if ( configPage2.injLayout == INJ_SEQUENTIAL ) { configPage4.inj4cylPairing = INJ_PAIR_13_24; } //Since #478 engine will always start in semi, make the sequence right for the majority of inlie 4 engines
      else { configPage4.inj4cylPairing = INJ_PAIR_14_23; } //Force setting to use the default mode from previous FW versions. This is to prevent issues on any setups that have been wired accordingly
    }

    configPage9.hardRevMode = 1; //Set hard rev limiter to Fixed mode
    configPage6.tachoMode = 0;

    //CAN broadcast introduced
    configPage4.CANBroadcastProtocol = CAN_BROADCAST_PROTOCOL_OFF;
    
    configPage15.boostDCWhenDisabled = 0;
    configPage15.boostControlEnable = EN_BOOST_CONTROL_BARO;
    
    //Fill the boostTableLookupDuty with all 50% duty cycle. This is the same as the hardcoded 50% DC that had been used before.
    //This makes the boostcontrol fully backwards compatible.  
    auto table_it = boostTableLookupDuty.values.begin();
    while (!table_it.at_end())
    {
      auto row = *table_it;
      while (!row.at_end())
      {
        *row = 50*2;
        ++row;
      }      
      ++table_it;
    }

    //Set some sensible values at the RPM axis
    auto table_X = boostTableLookupDuty.axisX.begin();
    uint16_t i = 0;
    while (!table_X.at_end())
    {
      ++i;
      *table_X = 1000+(500*i);
      ++table_X;
    }

    //Set some sensible values at the boosttarget axis
    auto table_Y = boostTableLookupDuty.axisY.begin();
    i = 0;
    while (!table_Y.at_end())
    {
      ++i;
      *table_Y = (120 + 10*i);
      ++table_Y;
    }

    //AFR Protection added, add default values
    configPage9.afrProtectEnabled = AFR_PROTECT_OFF; //Disable by default
    configPage9.afrProtectMinMAP = 90; //Is divided by 2, value represents 180kPa
    configPage9.afrProtectMinRPM = 40; //4000 RPM min
    configPage9.afrProtectMinTPS = 160; //80% TPS min
    configPage9.afrProtectDeviation = 14; //1.4 AFR deviation    
    
    saveAllPages();
    saveEEPROMVersion(20);
  }

  if(loadEEPROMVersion() == 20)
  {
    //202305
    configPage2.taeMinChange = 4; //Default is 2% minimum change to match prior behaviour. (4 = 2% account for 0.5 resolution)
    configPage2.maeMinChange = 2; //Default is 2% minimum change to match prior behaviour.

    configPage2.decelAmount = 100; //Default decel fuel amount is 100%, so no change in fueling in decel as before.
    //full status structure has been changed. Update programmable outputs settings to match.
    for (uint8_t y = 0; y < sizeof(configPage13.outputPin); y++)
    {
      if ((configPage13.firstDataIn[y] > 22) && (configPage13.firstDataIn[y] < 240)) {configPage13.firstDataIn[y]++;}
      if ((configPage13.firstDataIn[y] > 92) && (configPage13.firstDataIn[y] < 240)) {configPage13.firstDataIn[y]++;}
      if ((configPage13.secondDataIn[y] > 22) && (configPage13.secondDataIn[y] < 240)) {configPage13.secondDataIn[y]++;}
      if ((configPage13.secondDataIn[y] > 92) && (configPage13.secondDataIn[y] < 240)) {configPage13.secondDataIn[y]++;}
    }
    
    //AC Control (configPage15)
    //Set A/C default values - these line up with the ini file defaults
    configPage15.airConEnable = 0;

    //Oil Pressure protection delay added. Set to 0 to match existing behaviour
    configPage10.oilPressureProtTime = 0;

    //Option to power stepper motor constantly was added. Default to previous behaviour
    configPage9.iacStepperPower = 0;

    saveAllPages();
    saveEEPROMVersion(21);
  }

  if(loadEEPROMVersion() == 21)
  {
    //202310

    //Rolling cut curve added. Default values
    configPage15.rollingProtRPMDelta[0]   = -30;
    configPage15.rollingProtRPMDelta[1]   = -20;
    configPage15.rollingProtRPMDelta[2]   = -10;
    configPage15.rollingProtRPMDelta[3]   = -5;
    configPage15.rollingProtCutPercent[0] = 50;
    configPage15.rollingProtCutPercent[1] = 65;
    configPage15.rollingProtCutPercent[2] = 80;
    configPage15.rollingProtCutPercent[3] = 95;

    //DFCO Hyster was multiplied by 2 to allow a range of 0-500. Existing values must be halved
    configPage4.dfcoHyster = configPage4.dfcoHyster / 2;

    saveAllPages();
    saveEEPROMVersion(22);
  }

  if(loadEEPROMVersion() == 22)
  {
    //202402
    
    if( configPage10.wmiMode >= WMI_MODE_OPENLOOP ) { multiplyTableValue(wmiMapPage, 2); } //Increased PWM resolution from 0-100 to 0-200 to match VVT

    //Default values for pulsed hw test modes
    configPage13.hwTestInjDuration = 8;
    configPage13.hwTestIgnDuration = 4;

    //DFCO taper default values (Feature disabled by default)
    configPage9.dfcoTaperEnable = 0; //Disable
    configPage9.dfcoTaperTime = 10; //1 second
    configPage9.dfcoTaperFuel = 100; //Don't scale fuel
    configPage9.dfcoTaperAdvance = 20; //Reduce 20deg until full fuel cut
    
    //EGO MAP Limits
    configPage9.egoMAPMax = 255, // 255 will be 510 kpa
    configPage9.egoMAPMin = 0,  // 0 will be 0 kpa

    //rusEFI CAN Wideband
    configPage2.canWBO = 0;

    saveAllPages();
    saveEEPROMVersion(23);
  }

  if(loadEEPROMVersion() == 23)
  {
    //202501
    configPage10.knock_mode = KNOCK_MODE_OFF;

    //Change the CAN Broadcast settings to be a selection
    //Note that 1 preference will be lost if both BMW AND VAG protocols were enabled, but that is not a likely combination.
    if(configPage2.unused1_126_1 == true) { configPage4.CANBroadcastProtocol = CAN_BROADCAST_PROTOCOL_BMW; } //unused1_126_1 was canBMWCluster
    if(configPage2.unused1_126_2 == true) { configPage4.CANBroadcastProtocol = CAN_BROADCAST_PROTOCOL_VAG; } //unused1_126_2 was canVAGCluster

    //VSS max limit on launch control
    configPage10.lnchCtrlVss = 255;
    
    //Default all existing tunes to GM flex sensors
    configPage2.flexFreqLow = 50;
    configPage2.flexFreqHigh = 150;

    //Realign configPage10 to correct unaligned pointer warnings
    //Move boostIntv from position 27 to 25
    uint8_t origBoostIntv = ((uint8_t *)&configPage10)[27];
    ((uint8_t *)&configPage10)[27] = ((uint8_t *)&configPage10)[26];
    ((uint8_t *)&configPage10)[26] = ((uint8_t *)&configPage10)[25];
    ((uint8_t *)&configPage10)[25] = origBoostIntv;
    //Move lnchCtrlTPS from position 32 to 74
    uint8_t origlnchCtrlTPS= ((uint8_t *)&configPage10)[32];
    for(byte x=32U; x<74U; x++)
    {
      ((uint8_t *)&configPage10)[x] = ((uint8_t *)&configPage10)[x+1];
    }
    ((uint8_t *)&configPage10)[74] = origlnchCtrlTPS;

    saveAllPages();
    saveEEPROMVersion(24);
  }
  
  if(loadEEPROMVersion() == 24)
  {
    //202504
    saveEEPROMVersion(25);
  }
  upgradeV25toV26();
  //Move this #endif to only do latest updates to safe ROM space on small devices.
  #endif

  //Final check is always for 255 and 0 (Brand new arduino)
  if( (loadEEPROMVersion() == 0) || (loadEEPROMVersion() == 255) )
  {
    configPage9.true_address = 0x200;
    
    //Programmable outputs added. Set all to disabled
    configPage13.outputPin[0] = 0;
    configPage13.outputPin[1] = 0;
    configPage13.outputPin[2] = 0;
    configPage13.outputPin[3] = 0;
    configPage13.outputPin[4] = 0;
    configPage13.outputPin[5] = 0;
    configPage13.outputPin[6] = 0;
    configPage13.outputPin[7] = 0;

    configPage4.FILTER_FLEX = FILTER_FLEX_DEFAULT;

    saveEEPROMVersion(CURRENT_DATA_VERSION);
  }

  //Check to see if someone has downgraded versions:
  if( loadEEPROMVersion() > CURRENT_DATA_VERSION ) { saveEEPROMVersion(CURRENT_DATA_VERSION); }
}

void multiplyTableLoad(table3d_t *pTable, TableType key, uint8_t multiplier)
{
  auto y_it = y_begin(pTable, key);
  while(!y_it.at_end())
  {
    *y_it = *y_it * multiplier; 
    ++y_it;
  }
}

void divideTableLoad(table3d_t *pTable, TableType key, uint8_t divisor)
{
  auto y_it = y_begin(pTable, key);
  while(!y_it.at_end())
  {
    *y_it = *y_it / divisor; //Previous TS scale was 2.0, now is 0.5, 4x increase
    ++y_it;
  }
}

void multiplyTableValue(uint8_t pageNum, uint8_t multiplier)
{
  uint16_t count = getPageSize(pageNum);
  for (uint16_t i = 0; i < count; i++)
  {
    setPageValue(pageNum, i, (uint8_t)(getPageValue(pageNum, i) * multiplier));
  }
}

void divideTableValue(uint8_t pageNum, uint8_t divisor)
{
  uint16_t count = getPageSize(pageNum);
  for (uint16_t i = 0; i < count; i++)
  {
    setPageValue(pageNum, i, (uint8_t)(getPageValue(pageNum, i) / divisor));
  }
}
