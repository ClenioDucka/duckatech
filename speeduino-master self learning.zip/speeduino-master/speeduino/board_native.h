#pragma once

#if defined(NATIVE_BOARD)
#include <stdint.h>
#include <array>
#include <limits>
#include <USBAPI.h>
#include "../lib/ArduinoFake/SoftwareTimer.h"

/*
***********************************************************************************************************
* General
*/

/** @brief The timer overflow type
 * 
 * On some boards timers can overflow at less than the timer register width
 */
using COMPARE_TYPE = software_timer_t::counter_t;

/** @brief Convert µS to timer ticks */
constexpr auto uS_TO_TIMER_COMPARE = software_timer_t::microsToTicks;

/** @brief Convert timer ticks to µS */
constexpr auto ticksToMicros = software_timer_t::ticksToMicros;

#define FPU_MAX_SIZE 32 //Size of the FPU buffer. 0 means no FPU.
constexpr uint16_t BLOCKING_FACTOR = 121;
constexpr uint16_t TABLE_BLOCKING_FACTOR = 64;
#if !defined(IGN_CHANNELS)
#warning Using default IGN_CHANNELS
#define IGN_CHANNELS 8
#endif
#if !defined(INJ_CHANNELS)
#warning Using default INJ_CHANNELS
#define INJ_CHANNELS 8
#endif
#define TS_SERIAL_BUFFER_SIZE 517 //Size of the serial buffer used by new comms protocol. For SD transfers this must be at least 512 + 1 (flag) + 4 (sector)

#define BOARD_MAX_DIGITAL_PINS NUM_DIGITAL_PINS
#define BOARD_MAX_IO_PINS NUM_DIGITAL_PINS

static inline bool pinIsReserved(uint8_t pin) { return pin==0U; } //Forbidden pins like USB on other boards

#define PWM_FAN_AVAILABLE

/*
***********************************************************************************************************
* Schedules
*/
#define DEFINE_TIMER_VARS(Prefix, index, array) \
    static inline void Prefix##index##_TIMER_ENABLE(void) { array[index-1].enableTimer(); } \
    static inline void Prefix##index##_TIMER_DISABLE(void) { array[index-1].disableTimer(); } \
    static std::atomic<software_timer_t::counter_t>& Prefix##index##_COUNTER = array[index-1].counter; \
    static std::atomic<software_timer_t::counter_t>& Prefix##index##_COMPARE = array[index-1].compare;

extern std::array<software_timer_t, INJ_CHANNELS> fuelTimers;

DEFINE_TIMER_VARS(FUEL, 1, fuelTimers)
#if INJ_CHANNELS>=2
DEFINE_TIMER_VARS(FUEL, 2, fuelTimers)
#endif
#if INJ_CHANNELS>=3
DEFINE_TIMER_VARS(FUEL, 3, fuelTimers)
#endif
#if INJ_CHANNELS>=4
DEFINE_TIMER_VARS(FUEL, 4, fuelTimers)
#endif
#if INJ_CHANNELS>=5
DEFINE_TIMER_VARS(FUEL, 5, fuelTimers)
#endif
#if INJ_CHANNELS>=6
DEFINE_TIMER_VARS(FUEL, 6, fuelTimers)
#endif
#if INJ_CHANNELS>=7
DEFINE_TIMER_VARS(FUEL, 7, fuelTimers)
#endif
#if INJ_CHANNELS>=8
DEFINE_TIMER_VARS(FUEL, 8, fuelTimers)
#endif

extern std::array<software_timer_t, IGN_CHANNELS> ignitionTimers;

DEFINE_TIMER_VARS(IGN, 1, ignitionTimers)
#if IGN_CHANNELS>=2
DEFINE_TIMER_VARS(IGN, 2, ignitionTimers)
#endif
#if IGN_CHANNELS>=3
DEFINE_TIMER_VARS(IGN, 3, ignitionTimers)
#endif
#if IGN_CHANNELS>=4
DEFINE_TIMER_VARS(IGN, 4, ignitionTimers)
#endif
#if IGN_CHANNELS>=5
DEFINE_TIMER_VARS(IGN, 5, ignitionTimers)
#endif
#if IGN_CHANNELS>=6
DEFINE_TIMER_VARS(IGN, 6, ignitionTimers)
#endif
#if IGN_CHANNELS>=7
DEFINE_TIMER_VARS(IGN, 7, ignitionTimers)
#endif
#if IGN_CHANNELS>=8
DEFINE_TIMER_VARS(IGN, 8, ignitionTimers)
#endif

/*
***********************************************************************************************************
* Auxiliaries
*/

extern software_timer_t boostTimer;
#define ENABLE_BOOST_TIMER()  boostTimer.enableTimer()
#define DISABLE_BOOST_TIMER() boostTimer.disableTimer()
#define BOOST_TIMER_COMPARE   boostTimer.compare
#define BOOST_TIMER_COUNTER   boostTimer.counter

extern software_timer_t vvtTimer;
#define ENABLE_VVT_TIMER()    vvtTimer.enableTimer()
#define DISABLE_VVT_TIMER()   vvtTimer.disableTimer()
#define VVT_TIMER_COMPARE     vvtTimer.compare
#define VVT_TIMER_COUNTER     vvtTimer.counter

extern software_timer_t fanTimer;
#define ENABLE_FAN_TIMER()  fanTimer.enableTimer()
#define DISABLE_FAN_TIMER() fanTimer.disableTimer()
#define FAN_TIMER_COMPARE     fanTimer.compare
#define FAN_TIMER_COUNTER     fanTimer.counter

/*
***********************************************************************************************************
* Idle
*/
extern software_timer_t idleTimer;
#define IDLE_TIMER_ENABLE()  idleTimer.enableTimer()
#define IDLE_TIMER_DISABLE() idleTimer.disableTimer()
#define IDLE_COUNTER   idleTimer.counter
#define IDLE_COMPARE   idleTimer.compare

#define ATOMIC() \
    for ( \
        struct { TickEventGuard guard; uint8_t done = 1; } loopGuard; \
        loopGuard.done; loopGuard.done = 0U )

#if !defined(max)
template<typename _Tp>
constexpr const _Tp& max(const _Tp& __a, const _Tp& __b) {
    if (__b > __a) {
        return __b;
    }
    return __a;
}
#endif
#if !defined(min)
template<typename _Tp>
constexpr const _Tp& min(const _Tp& __a, const _Tp& __b) {
    if (__b < __a) {
        return __b;
    }
    return __a;
}
#endif

/*
***********************************************************************************************************
* CAN / Second serial
*/
#define SECONDARY_SERIAL_T decltype(Serial)

#define RTC_LIB_H <time.h>

class inputPin_t;
using boardInputPin_t = inputPin_t;
class outputPin_t;
using boardOutputPin_t = outputPin_t;

/** @brief Analog pin mapping */
constexpr uint8_t ANALOG_PINS[] = { _ANALOG_PINS_A0_A14 };

/** @brief When the serial buffer is filled to greater than this threshold
 * value, the serial processing operations will be performed more urgently 
 * in order to avoid it overflowing. 
 */
constexpr uint8_t SERIAL_BUFFER_THRESHOLD = 0U;

#endif // NATIVE_BOARD