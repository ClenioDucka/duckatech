/** @file
 * Instantiation of various (table2D, table3D) tables, volatile (interrupt modified) variables, Injector (1...8) enablement flags, etc.
 */
#include "globals.h"

struct table3d16RpmLoad fuelTable; ///< 16x16 fuel map
struct table3d16RpmLoad fuelTable2; ///< 16x16 fuel map
struct table3d16RpmLoad ignitionTable; ///< 16x16 ignition map
struct table3d16RpmLoad ignitionTable2; ///< 16x16 ignition map
struct table3d16RpmLoad afrTable; ///< 16x16 afr target map
struct table3d8RpmLoad stagingTable; ///< 8x8 fuel staging table
struct table3d8RpmLoad boostTable; ///< 8x8 boost map
struct table3d8RpmLoad boostTableLookupDuty; ///< 8x8 boost map lookup table
struct table3d8RpmLoad vvtTable; ///< 8x8 vvt map
struct table3d8RpmLoad vvt2Table; ///< 8x8 vvt2 map
struct table3d8RpmLoad wmiTable; ///< 8x8 wmi map
struct table3d6RpmLoad trimTables[INJ_CHANNELS];
struct table3d4RpmLoad dwellTable; ///< 4x4 Dwell map

//These are variables used across multiple files
uint8_t softLimitTime = 0; //The time (in 0.1 seconds, based on seclx10) that the soft limiter started
volatile uint16_t mainLoopCount; //Main loop counter (incremented at each main loop rev., used for maintaining currentStatus.loopsPerSecond)
volatile unsigned long ms_counter = 0; //A counter that increments once per ms
uint16_t fixedCrankingOverride = 0;
volatile uint32_t toothHistory[TOOTH_LOG_SIZE]; ///< Tooth trigger history - delta time (in uS) from last tooth (Indexed by @ref toothHistoryIndex)
volatile uint8_t compositeLogHistory[TOOTH_LOG_SIZE];
// Some code relies on tooth log containing less than UINT8_MAX items.
static_assert(_countof(toothHistory)<UINT8_MAX, "Check all uses of toothHistory/toothHistoryIndex etc.");
volatile unsigned int toothHistoryIndex = 0; ///< Current index to @ref toothHistory array
unsigned long currentLoopTime; /**< The time (in uS) that the current mainloop started */
volatile uint16_t ignitionCount; /**< The count of ignition events that have taken place since the engine started */
int16_t CRANK_ANGLE_MAX_IGN = 360;
int16_t CRANK_ANGLE_MAX_INJ = 360; ///< The number of crank degrees that the system track over. Typically 720 divided by the number of squirts per cycle (Eg 360 for wasted 2 squirt and 720 for sequential single squirt)
volatile uint32_t runSecsX10;
volatile uint32_t seclx10;
volatile byte HWTest_INJ = 0; /**< Each bit in this variable represents one of the injector channels and it's HW test status */
volatile byte HWTest_INJ_Pulsed = 0; /**< Each bit in this variable represents one of the injector channels and it's pulsed HW test status */
volatile byte HWTest_IGN = 0; /**< Each bit in this variable represents one of the ignition channels and it's HW test status */
volatile byte HWTest_IGN_Pulsed = 0; 

/// Various pin numbering (Injectors, Ign outputs, CAS, Cam, Sensors. etc.) assignments
byte pinInjector1; ///< Output pin injector 1
byte pinInjector2; ///< Output pin injector 2
byte pinInjector3; ///< Output pin injector 3
byte pinInjector4; ///< Output pin injector 4
byte pinInjector5; ///< Output pin injector 5
byte pinInjector6; ///< Output pin injector 6
byte pinInjector7; ///< Output pin injector 7
byte pinInjector8; ///< Output pin injector 8
byte pinCoil1; ///< Pin for coil 1
byte pinCoil2; ///< Pin for coil 2
byte pinCoil3; ///< Pin for coil 3
byte pinCoil4; ///< Pin for coil 4
byte pinCoil5; ///< Pin for coil 5
byte pinCoil6; ///< Pin for coil 6
byte pinCoil7; ///< Pin for coil 7
byte pinCoil8; ///< Pin for coil 8
byte pinTrigger;  ///< RPM1 (Typically CAS=crankshaft angle sensor) pin
byte pinTrigger2; ///< RPM2 (Typically the Cam Sensor) pin
byte pinTrigger3;	///< the 2nd cam sensor pin
byte pinTPS;      //TPS input pin
byte pinMAP;      //MAP sensor pin
byte pinEMAP;     //EMAP sensor pin
byte pinMAP2;     //2nd MAP sensor (Currently unused)
byte pinIAT;      //IAT sensor pin
byte pinCLT;      //CLS sensor pin
byte pinO2;       //O2 Sensor pin
byte pinO2_2;     //second O2 pin
byte pinBat;      //Battery voltage pin
byte pinDisplayReset; // OLED reset pin
byte pinTachOut;  //Tacho output
byte pinFuelPump; //Fuel pump on/off
byte pinIdle1;    //Single wire idle control
byte pinIdle2;    //2 wire idle control (Not currently used)
byte pinIdleUp;   //Input for triggering Idle Up
byte pinIdleUpOutput; //Output that follows (normal or inverted) the idle up pin
byte pinCTPS;     //Input for triggering closed throttle state
byte pinFuel2Input;  //Input for switching to the 2nd fuel table
byte pinSpark2Input; //Input for switching to the 2nd ignition table
byte pinSpareTemp1;  // Future use only
byte pinSpareTemp2;  // Future use only
byte pinSpareOut1;  //Generic output
byte pinSpareOut2;  //Generic output
byte pinSpareOut3;  //Generic output
byte pinSpareOut4;  //Generic output
byte pinSpareOut5;  //Generic output
byte pinSpareOut6;  //Generic output
byte pinSpareHOut1; //spare high current output
byte pinSpareHOut2; // spare high current output
byte pinSpareLOut1; // spare low current output
byte pinSpareLOut2; // spare low current output
byte pinSpareLOut3;
byte pinSpareLOut4;
byte pinSpareLOut5;
byte pinBoost;
byte pinVVT_1;     ///< vvt (variable valve timing) output 1
byte pinVVT_2;     ///< vvt (variable valve timing) output 2
byte pinFan;       ///< Cooling fan output (on/off? See: auxiliaries.ino)
byte pinStepperDir; //Direction pin for the stepper motor driver
byte pinStepperStep; //Step pin for the stepper motor driver
byte pinStepperEnable; //Turning the DRV8825 driver on/off
byte pinLaunch;
byte pinIgnBypass; //The pin used for an ignition bypass (Optional)
byte pinFlex; //Pin with the flex sensor attached
byte pinVSS;  // VSS (Vehicle speed sensor) Pin
byte pinBaro; //Pin that an al barometric pressure sensor is attached to (If used)
byte pinResetControl; // Output pin used control resetting the Arduino
byte pinFuelPressure;
byte pinOilPressure;
byte pinWMIEmpty; // Water tank empty sensor
byte pinWMIIndicator; // No water indicator bulb
byte pinWMIEnabled; // ON-OFF output to relay/pump/solenoid 
byte pinMC33810_1_CS;
byte pinMC33810_2_CS;
byte pinSDEnable;
#ifdef USE_SPI_EEPROM
  byte pinSPIFlash_CS;
#endif
byte pinAirConComp;     // Air conditioning compressor output (See: auxiliaries.ino)
byte pinAirConFan;    // Stand-alone air conditioning fan output (See: auxiliaries.ino)
byte pinAirConRequest;  // Air conditioning request input (See: auxiliaries.ino)

struct statuses currentStatus; /**< The master global "live" status struct. Contains all values that are updated frequently and used across modules */
struct config2 configPage2;
struct config4 configPage4;
struct config6 configPage6;
struct config9 configPage9;
struct config10 configPage10;
struct config13 configPage13;
struct config15 configPage15;

//These function do checks on a pin to determine if it is already in use by another (higher importance) active function
bool pinIsOutput(byte pin)
{
  bool used = false;
  bool isIdlePWM = isPwmIac(configPage6);
  bool isIdleStepper = isStepperIac(configPage6);
  //Injector?
  if ((pin == pinInjector1)
  || ((pin == pinInjector2) && (configPage2.nInjectors > 1))
  || ((pin == pinInjector3) && (configPage2.nInjectors > 2))
  || ((pin == pinInjector4) && (configPage2.nInjectors > 3))
  || ((pin == pinInjector5) && (configPage2.nInjectors > 4))
  || ((pin == pinInjector6) && (configPage2.nInjectors > 5))
  || ((pin == pinInjector7) && (configPage2.nInjectors > 6))
  || ((pin == pinInjector8) && (configPage2.nInjectors > 7)))
  {
    used = true;
  }
  //Ignition?
  if ((pin == pinCoil1)
  || ((pin == pinCoil2) && (currentStatus.maxIgnOutputs > 1))
  || ((pin == pinCoil3) && (currentStatus.maxIgnOutputs > 2))
  || ((pin == pinCoil4) && (currentStatus.maxIgnOutputs > 3))
  || ((pin == pinCoil5) && (currentStatus.maxIgnOutputs > 4))
  || ((pin == pinCoil6) && (currentStatus.maxIgnOutputs > 5))
  || ((pin == pinCoil7) && (currentStatus.maxIgnOutputs > 6))
  || ((pin == pinCoil8) && (currentStatus.maxIgnOutputs > 7)))
  {
    used = true;
  }
  //Functions?
  if ((pin == pinFuelPump)
  || ((pin == pinFan) && (configPage2.fanEnable == 1))
  || ((pin == pinVVT_1) && (configPage6.vvtEnabled > 0))
  || ((pin == pinVVT_2) && (configPage10.wmiEnabled > 0))
  || ((pin == pinVVT_2) && (configPage10.vvt2Enabled > 0))
  || ((pin == pinBoost) && (configPage6.boostEnabled == 1))
  || ((pin == pinIdle1) && isIdlePWM)
  || ((pin == pinIdle2) && isIdlePWM && (configPage6.iacChannels == 1))
  || ((pin == pinStepperEnable) && isIdleStepper)
  || ((pin == pinStepperStep) && isIdleStepper)
  || ((pin == pinStepperDir) && isIdleStepper)
  || (pin == pinTachOut)
  || ((pin == pinAirConComp) && (configPage15.airConEnable > 0))
  || ((pin == pinAirConFan) && (configPage15.airConEnable > 0) && (configPage15.airConFanEnabled > 0)) )
  {
    used = true;
  }
  //Forbidden or hardware reserved? (Defined at board_xyz.h file)
  if ( pinIsReserved(pin) ) { used = true; }

  return used;
}

#define pinIsSensor(pin)    ( ((pin) == pinCLT) || ((pin) == pinIAT) || ((pin) == pinMAP) || ((pin) == pinTPS) || ((pin) == pinO2) || ((pin) == pinBat) || (((pin) == pinFlex) && (configPage2.flexEnabled != 0)) )

bool pinIsUsed(byte pin)
{
  bool used = false;

  //Analog input?
  if ( pinIsSensor(pin) )
  {
    used = true;
  }
  //Functions?
  if ( pinIsOutput(pin) )
  {
    used = true;
  }

  return used;
}
